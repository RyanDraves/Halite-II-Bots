#include "hlt/hlt.hpp"
#include "hlt/navigation.hpp"

//Credit to skylarh for these useful functions (not neccessarily in their original form).
hlt::Planet FindClosestPlanet(const hlt::Ship& ship, std::vector<hlt::Planet> planets, hlt::PlayerId player_id);

int main() {
    const hlt::Metadata metadata = hlt::initialize("IvanTheTerrible");
    const hlt::PlayerId player_id = metadata.player_id;

    const hlt::Map& initial_map = metadata.initial_map;

    // We now have 1 full minute to analyse the initial map.
    std::ostringstream initial_map_intelligence;
    initial_map_intelligence
            << "width: " << initial_map.map_width
            << "; height: " << initial_map.map_height
            << "; players: " << initial_map.ship_map.size()
            << "; my ships: " << initial_map.ship_map.at(player_id).size()
            << "; planets: " << initial_map.planets.size();
    hlt::Log::log(initial_map_intelligence.str());

    std::vector<hlt::Move> moves;
    for (;;) {
        moves.clear();
        const hlt::Map map = hlt::in::get_map();

        for (const hlt::Ship& ship : map.ships.at(player_id)) {
			//Stay docked if you are.
            if (ship.docking_status != hlt::ShipDockingStatus::Undocked) {
                continue;
            }

			//Find the closest planet that is not fully docked by me.
			const hlt::Planet& target_planet = FindClosestPlanet(ship, map.planets, player_id);

			//If nobody owns the planet,
            if (!target_planet.owned) {
				//find the nearest enemy,
				//hlt::Ship nearest_enemy = 
				//dock if you can,
				//if (ship.location.get_distance_to(target_planet.location) <= target_planet.radius + hlt::constants::DOCK_RADIUS && ship.location.get_distance_to(target_planet.location) < ship.location.get_distance_to(my_target.location)) {
					if (ship.can_dock(target_planet)) {
						moves.push_back(hlt::Move::dock(ship.entity_id, target_planet.entity_id));
						continue;
					}
				//}
				
				//or just move to it
				const hlt::possibly<hlt::Move> move =
					hlt::navigation::navigate_ship_to_dock(map, ship, target_planet, hlt::constants::MAX_SPEED);
				if (move.second) {
					moves.push_back(move.first);
				}
				continue;
			}
			//or I need more ships docked to mine,
			else if (target_planet.owner_id == player_id) {
				//dock if you can,
				if (ship.can_dock(target_planet)) {
					moves.push_back(hlt::Move::dock(ship.entity_id, target_planet.entity_id));
					continue;
				}
				//or just move to it
				const hlt::possibly<hlt::Move> move =
					hlt::navigation::navigate_ship_to_dock(map, ship, target_planet, hlt::constants::MAX_SPEED);
				if (move.second) {
					moves.push_back(move.first);
				}
				continue;
			}
			//otherwise it's not mine, so
			else {
				//find the first ship docked to it,
				hlt::Ship my_target = map.get_ship(target_planet.owner_id, target_planet.docked_ships[0]);
				//compare if I need to go around the planet (pathing bug, checks if I'm close to planet and if the planet center is closer than the docked ship),
				/*if (ship.location.get_distance_to(target_planet.location) <= target_planet.radius + hlt::constants::DOCK_RADIUS && ship.location.get_distance_to(target_planet.location) < ship.location.get_distance_to(my_target.location)) {
					hlt::Location new_location = { 0, 0 };
					//	this equates to target_planet - (ship - target_planet)
					new_location.pos_x = 2 * target_planet.location.pos_x - ship.location.pos_x;
					new_location.pos_y = 2 * target_planet.location.pos_y - ship.location.pos_y;
					const hlt::possibly<hlt::Move> move =
						hlt::navigation::navigate_ship_towards_target(map, ship, new_location, hlt::constants::MAX_SPEED, true, hlt::constants::MAX_NAVIGATION_CORRECTIONS, M_PI / 45);
					if (move.second) {
						moves.push_back(move.first);
					}
				}
				else {*/
					//otherwise the ship is a ways out yet or the target is close, go ahead and move to attack it.
					const hlt::possibly<hlt::Move> move =
						hlt::navigation::navigate_ship_to_almost_target(map, ship, my_target, hlt::constants::MAX_SPEED);
					if (move.second) {
						moves.push_back(move.first);
					}
				//}
			}
        }

        if (!hlt::out::send_moves(moves)) {
            hlt::Log::log("send_moves failed; exiting");
            break;
        }
    }
}

hlt::Planet FindClosestPlanet(const hlt::Ship& ship, std::vector<hlt::Planet> planets, hlt::PlayerId player_id) {
	// find closest planet
	hlt::Planet current_planet = planets[0];
	double shortest = 100000000;

	for (const hlt::Planet& planet : planets) {
		if ((!planet.is_full() && planet.owner_id == player_id) || planet.owner_id != player_id) {
			double dist = ship.location.get_distance_to(planet.location);
			if (dist < shortest) {
				current_planet = planet;
				shortest = dist;
			}
		}
	}

	return current_planet;
}