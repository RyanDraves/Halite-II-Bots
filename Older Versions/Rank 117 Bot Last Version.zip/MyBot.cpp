#include "hlt/hlt.hpp"
#include "hlt/navigation.hpp"

#define NO_RADIUS 100000000

//Defensive Functions
hlt::Planet FindClosestAnyPlanet(const hlt::Ship& ship, std::vector<hlt::Planet> planets);
bool EnemyNearPlanet(const hlt::Planet& planet, const hlt::Map& map, hlt::PlayerId player_id);

//Offensive Functions

hlt::Ship FindClosestShip(const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id, double radius);
hlt::Ship FindABuddy(const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id, double radius);
//Credit to skylarh for this useful function (not neccessarily in its original form).
hlt::Planet FindClosestPlanet(const hlt::Ship& ship, std::vector<hlt::Planet> planets, hlt::PlayerId player_id);
bool EnoughAlliesCloser(const hlt::Planet& planet, const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id);
hlt::Planet FindNextPlanet(const hlt::Planet& planet, const hlt::Ship& ship, std::vector<hlt::Planet> planets, hlt::PlayerId player_id);
hlt::Ship NearestDockedShip(const hlt::Ship& ship, const hlt::Planet& planet, const hlt::Map& map);


int main() {
    const hlt::Metadata metadata = hlt::initialize("IvanTheTerrible");
    const hlt::PlayerId player_id = metadata.player_id;

    const hlt::Map& initial_map = metadata.initial_map;

    // We now have 1 full minute to analyse the initial map.
    std::ostringstream initial_map_intelligence;
    initial_map_intelligence
            << "width: " << initial_map.map_width
            << "; height: " << initial_map.map_height
            << "; players: " << initial_map.ship_map.size()
            << "; my ships: " << initial_map.ship_map.at(player_id).size()
            << "; planets: " << initial_map.planets.size();
    hlt::Log::log(initial_map_intelligence.str());

    std::vector<hlt::Move> moves;
    for (;;) {
        moves.clear();
        const hlt::Map map = hlt::in::get_map();

        for (const hlt::Ship& ship : map.ships.at(player_id)) {
			//Stay docked if you are.
            if (ship.docking_status != hlt::ShipDockingStatus::Undocked) {
                continue;
            }

			/*
			Defense strategy:
			1. Is there a near enemy?
			2. Attack it.
			*/

			hlt::Planet nearest_planet = FindClosestAnyPlanet(ship, map.planets);
			if (nearest_planet.owner_id == player_id) {
				if (EnemyNearPlanet(nearest_planet, map, player_id)) {
					hlt::Ship nearest_enemy = FindClosestShip(ship, map, player_id, NO_RADIUS);
					const hlt::possibly<hlt::Move> move =
						hlt::navigation::navigate_ship_to_almost_target(map, ship, nearest_enemy, hlt::constants::MAX_SPEED);
					if (move.second) {
						moves.push_back(move.first);
					}
					continue;
				}
			}

			/*
			The current strategy is to locate the closest planet that is either not full or not owned by me, and run a unique strategy for each three cases of ownership:

			1. Not owned.
				- If there are nearby enemies (scaling with planet radius), target them first.
				- Otherwise, try to dock.
				- Otherwise, if you have no enemies in a really large radius and there are more than enough ships heading to the planet, find a new planet to target.
				- Note: The ship just needs to move to this second closest one, once it's the closest it'll automatically run the appropriate code for that planet.
				- Otherwise, continue moving towards the planet and run some kind of anti-collision check for close allies.
			2. Owned by me but it needs more docked ships.
				- Attack any nearby enemies (why did this planet need another ship?).
				- Otherwise dock or move to it.
			3. Owned by someone else.
				- Attack the closest docked ship.
			*/

			//Find the closest planet that is not fully docked by me.
			const hlt::Planet& target_planet = FindClosestPlanet(ship, map.planets, player_id);

			//If nobody owns the planet,
            if (!target_planet.owned) {
				//find the nearest enemy,
				hlt::Ship nearest_enemy = FindClosestShip(ship, map, player_id, NO_RADIUS);
				//if there are no nearby enemies within a certain range,
				if (ship.location.get_distance_to(nearest_enemy.location) > target_planet.radius * 3.0) {
					//try to dock,
					if (ship.can_dock(target_planet)) {
						moves.push_back(hlt::Move::dock(ship.entity_id, target_planet.entity_id));
					}
					//or if I can't dock,
					else {
						//check if there is a need for more ships to go to the planet,
						if (target_planet.location.get_distance_to(nearest_enemy.location) < 50.0 || !EnoughAlliesCloser(target_planet, ship, map, player_id)) {
							//then check if there is a dangerously close ally,
							hlt::Ship close_ally = FindABuddy(ship, map, player_id, 3.0);
							//and if the buddy is closer than you,
							if (ship.location.get_distance_to(target_planet.location) > close_ally.location.get_distance_to(target_planet.location)) {
								//move just under max speed.
								const hlt::possibly<hlt::Move> move =
									hlt::navigation::navigate_ship_to_dock(map, ship, target_planet, hlt::constants::MAX_SPEED - 0.5);
								if (move.second) {
									moves.push_back(move.first);
								}
							}
							//if the buddy is behind you/is you,
							else {
								//move at max speed.
								const hlt::possibly<hlt::Move> move =
									hlt::navigation::navigate_ship_to_dock(map, ship, target_planet, hlt::constants::MAX_SPEED);
								if (move.second) {
									moves.push_back(move.first);
								}
							}
						}
						//otherwise locate the second closest planet,
						else {
							const hlt::Planet& new_target = FindNextPlanet(target_planet, ship, map.planets, player_id);
							//then move to it (other logic path will occur when it's the closest).
							const hlt::possibly<hlt::Move> move =
								hlt::navigation::navigate_ship_to_dock(map, ship, new_target, hlt::constants::MAX_SPEED);
							if (move.second) {
								moves.push_back(move.first);
							}
						}
					}
				}
				//otherwise there is a nearby enemy,
				else {
					//so attack it.
					const hlt::possibly<hlt::Move> move =
						hlt::navigation::navigate_ship_to_almost_target(map, ship, nearest_enemy, hlt::constants::MAX_SPEED);
					if (move.second) {
						moves.push_back(move.first);
					}
				}
			}
			//or I need more ships docked to mine,
			else if (target_planet.owner_id == player_id) {
				//check for nearby enemies,
				hlt::Ship nearest_enemy = FindClosestShip(ship, map, player_id, NO_RADIUS);
				//and if there are no nearby enemies relative to the planet and the ship is needed,
				if (target_planet.location.get_distance_to(nearest_enemy.location) > 20 && !EnoughAlliesCloser(target_planet, ship, map, player_id)) {
					//dock if you can,
					if (ship.can_dock(target_planet)) {
						moves.push_back(hlt::Move::dock(ship.entity_id, target_planet.entity_id));
					}
					//or move to it.
					else {
						const hlt::possibly<hlt::Move> move =
							hlt::navigation::navigate_ship_to_dock(map, ship, target_planet, hlt::constants::MAX_SPEED);
						if (move.second) {
							moves.push_back(move.first);
						}
					}
				}
				//or if there's an enemy nearby/enough ships heading to fill the spot,
				else {
					//attack the nearest enemy.
					const hlt::possibly<hlt::Move> move =
						hlt::navigation::navigate_ship_to_almost_target(map, ship, nearest_enemy, hlt::constants::MAX_SPEED);
					if (move.second) {
						moves.push_back(move.first);
					}
				}
			}
			//otherwise it's not mine,
			else {
				//so find the closest ship docked to it,
				hlt::Ship nearest_docked_ship = NearestDockedShip(ship, target_planet, map);
				//then attack it.
				const hlt::possibly<hlt::Move> move =
					hlt::navigation::navigate_ship_to_almost_target(map, ship, nearest_docked_ship, hlt::constants::MAX_SPEED);
				if (move.second) {
					moves.push_back(move.first);
				}
			}
        }

        if (!hlt::out::send_moves(moves)) {
            hlt::Log::log("send_moves failed; exiting");
            break;
        }
    }
}

//
//Defensive functions
//

hlt::Planet FindClosestAnyPlanet(const hlt::Ship& ship, std::vector<hlt::Planet> planets) {
	//Returns the closest planet.
	hlt::Planet current_planet = planets[0];
	double shortest = NO_RADIUS;

	for (const hlt::Planet& planet : planets) {
		double dist = ship.location.get_distance_to(planet.location);
		if (dist < shortest) {
			current_planet = planet;
			shortest = dist;
		}
	}

	return current_planet;
}

bool EnemyNearPlanet(const hlt::Planet& planet, const hlt::Map& map, hlt::PlayerId player_id) {
	for (const auto& player_ship : map.ships) {
		for (const hlt::Ship& potential_ship : player_ship.second) {
			if (potential_ship.owner_id != player_id) {
				if (potential_ship.location.get_distance_to(planet.location) < planet.radius * 2.0) {
					return true;
				}
			}
		}
	}

	return false;
}

//
//Offensive functions
//

hlt::Ship FindClosestShip(const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id, double radius) {
	//Returns the ship if there are no near enemies.
	hlt::Ship current_ship = ship;

	for (const auto& player_ship : map.ships) {
		for (const hlt::Ship& potential_ship : player_ship.second) {
			if (potential_ship.owner_id != player_id) {
				double dist = ship.location.get_distance_to(potential_ship.location);
				if (dist < radius) {
					current_ship = potential_ship;
					radius = dist;
				}
			}
		}
	}

	return current_ship;
}

hlt::Ship FindABuddy(const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id, double radius) {
	//Returns the ship if there are no near buddies, or the nearest buddy if there is one.
	hlt::Ship current_ship = ship;

	for (const hlt::Ship& s : map.ships.at(player_id)) {
		if (s.entity_id != ship.entity_id && s.docking_status == hlt::ShipDockingStatus::Undocked) {
			double dist = ship.location.get_distance_to(s.location);
			if (dist < radius) {
				current_ship = s;
				radius = dist;
			}
		}
	}

	return current_ship;
}

hlt::Planet FindClosestPlanet(const hlt::Ship& ship, std::vector<hlt::Planet> planets, hlt::PlayerId player_id) {
	//Returns the closest planet unless it's owned by me and full.
	hlt::Planet current_planet = planets[0];
	double shortest = NO_RADIUS;

	for (const hlt::Planet& planet : planets) {
		if ((!planet.is_full() && planet.owner_id == player_id) || planet.owner_id != player_id) {
			double dist = ship.location.get_distance_to(planet.location);
			if (dist < shortest) {
				current_planet = planet;
				shortest = dist;
			}
		}
	}

	return current_planet;
}

bool EnoughAlliesCloser(const hlt::Planet& planet, const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id) {
	//Returns true if there are at least the amount of docking spots left in numbers of allied ships closer to the target planet.
	double range = ship.location.get_distance_to(planet.location);
	unsigned int closer = 0;

	//If any ship is not the entered ship, docked, or farther than the entered ship, add one to closer.
	for (const hlt::Ship& s : map.ships.at(player_id)) {
		if (s.entity_id != ship.entity_id && s.docking_status == hlt::ShipDockingStatus::Undocked && s.location.get_distance_to(planet.location) < range) {
			closer++;
		}
	}

	//If close is greater than or equal to the amount of spots left, return true.
	if (closer >= planet.docking_spots - planet.docked_ships.size()) {
		return true;
	}
	else {
		return false;
	}
}

hlt::Planet FindNextPlanet(const hlt::Planet& planet, const hlt::Ship& ship, std::vector<hlt::Planet> planets, hlt::PlayerId player_id) {
	//Returns the second closest planet unless it's owned by me and full. Uses the current closest to sort.
	hlt::Planet current_planet = planets[0];
	double shortest = NO_RADIUS;

	for (const hlt::Planet& p : planets) {
		if ((!p.is_full() && p.owner_id == player_id) || p.owner_id != player_id) {
			if (p.entity_id != planet.entity_id) {
				double dist = ship.location.get_distance_to(p.location);
				if (dist < shortest) {
					current_planet = p;
					shortest = dist;
				}
			}
		}
	}

	return current_planet;
}

hlt::Ship NearestDockedShip(const hlt::Ship& ship, const hlt::Planet& planet, const hlt::Map& map) {
	hlt::Ship current_ship;
	double shortest = NO_RADIUS;

	for (const hlt::EntityId& e : planet.docked_ships) {
		hlt::Ship s = map.get_ship(planet.owner_id, e);
		double dist = ship.location.get_distance_to(s.location);
		if (dist < shortest) {
			current_ship = s;
			shortest = dist;
		}
	}

	return current_ship;
}