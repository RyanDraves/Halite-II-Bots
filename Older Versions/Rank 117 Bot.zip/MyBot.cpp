#include "hlt/hlt.hpp"
#include "hlt/navigation.hpp"

hlt::Ship FindClosestShip(const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id, double radius);
hlt::Ship FindABuddy(const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id, double radius);
//Credit to skylarh for these useful functions (not neccessarily in their original form).
hlt::Planet FindClosestPlanet(const hlt::Ship& ship, std::vector<hlt::Planet> planets, hlt::PlayerId player_id);

int main() {
    const hlt::Metadata metadata = hlt::initialize("IvanTheTerrible");
    const hlt::PlayerId player_id = metadata.player_id;

    const hlt::Map& initial_map = metadata.initial_map;

    // We now have 1 full minute to analyse the initial map.
    std::ostringstream initial_map_intelligence;
    initial_map_intelligence
            << "width: " << initial_map.map_width
            << "; height: " << initial_map.map_height
            << "; players: " << initial_map.ship_map.size()
            << "; my ships: " << initial_map.ship_map.at(player_id).size()
            << "; planets: " << initial_map.planets.size();
    hlt::Log::log(initial_map_intelligence.str());

    std::vector<hlt::Move> moves;
    for (;;) {
        moves.clear();
        const hlt::Map map = hlt::in::get_map();

        for (const hlt::Ship& ship : map.ships.at(player_id)) {
			//Stay docked if you are.
            if (ship.docking_status != hlt::ShipDockingStatus::Undocked) {
                continue;
            }

			//Find the closest planet that is not fully docked by me.
			const hlt::Planet& target_planet = FindClosestPlanet(ship, map.planets, player_id);

			//If nobody owns the planet,
            if (!target_planet.owned) {
				//find the nearest enemy,
				hlt::Ship nearest_enemy = FindClosestShip(ship, map, player_id, target_planet.radius * 3);
				//if there are no nearby enemies,
				if (nearest_enemy.entity_id == ship.entity_id) {
					//try to dock,
					if (ship.can_dock(target_planet)) {
						moves.push_back(hlt::Move::dock(ship.entity_id, target_planet.entity_id));
						continue;
					}
					//or if I can't dock,
					else {
						//check if there is a dangerously close ally,
						hlt::Ship close_ally = FindABuddy(ship, map, player_id, 3.0);
						//if not,
						if (close_ally.entity_id == ship.entity_id) {
							//move to the unowned planet.
							const hlt::possibly<hlt::Move> move =
								hlt::navigation::navigate_ship_to_dock(map, ship, target_planet, hlt::constants::MAX_SPEED);
							if (move.second) {
								moves.push_back(move.first);
							}
							continue;
						}
						//or if so,
						else {
							//move away from the ally.
							hlt::Location avoid_ally = ship.location;
							avoid_ally.pos_x -= close_ally.location.pos_x - ship.location.pos_x;
							avoid_ally.pos_y -= close_ally.location.pos_y - ship.location.pos_y;
							const hlt::possibly<hlt::Move> move =
								hlt::navigation::navigate_ship_towards_target(map, ship, avoid_ally, (int)ship.location.get_distance_to(close_ally.location), true, hlt::constants::MAX_NAVIGATION_CORRECTIONS, M_PI / 180.0);
							if (move.second) {
								moves.push_back(move.first);
							}
							continue;
						}
					}
				}
				//otherwise there is a nearby enemy,
				else {
					//so attack it.
					const hlt::possibly<hlt::Move> move =
						hlt::navigation::navigate_ship_to_almost_target(map, ship, nearest_enemy, hlt::constants::MAX_SPEED);
					if (move.second) {
						moves.push_back(move.first);
					}
				}
			}
			//or I need more ships docked to mine,
			else if (target_planet.owner_id == player_id) {
				//check for nearby enemies,
				hlt::Ship nearest_enemy = FindClosestShip(ship, map, player_id, 20.0);
				//and if there are no nearby enemies,
				if (nearest_enemy.entity_id == ship.entity_id) {
					//dock if you can,
					if (ship.can_dock(target_planet)) {
						moves.push_back(hlt::Move::dock(ship.entity_id, target_planet.entity_id));
						continue;
					}
					//or move to it.
					const hlt::possibly<hlt::Move> move =
						hlt::navigation::navigate_ship_to_dock(map, ship, target_planet, hlt::constants::MAX_SPEED);
					if (move.second) {
						moves.push_back(move.first);
					}
					continue;
				}
				//or if there's an enemy nearby,
				else {
					//attack it.
					const hlt::possibly<hlt::Move> move =
						hlt::navigation::navigate_ship_to_almost_target(map, ship, nearest_enemy, hlt::constants::MAX_SPEED);
					if (move.second) {
						moves.push_back(move.first);
					}
				}
			}
			//otherwise it's not mine,
			else {
				//so find the first ship docked to it,
				hlt::Ship nearest_docked_ship = map.get_ship(target_planet.owner_id, target_planet.docked_ships[0]);
				//then attack it.
				const hlt::possibly<hlt::Move> move =
					hlt::navigation::navigate_ship_to_almost_target(map, ship, nearest_docked_ship, hlt::constants::MAX_SPEED);
				if (move.second) {
					moves.push_back(move.first);
				}
			}
        }

        if (!hlt::out::send_moves(moves)) {
            hlt::Log::log("send_moves failed; exiting");
            break;
        }
    }
}

hlt::Ship FindClosestShip(const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id, double radius) {
	//Returns the ship if there are no near enemies.
	hlt::Ship current_ship = ship;

	for (const auto& player_ship : map.ships) {
		for (const hlt::Ship& potential_ship : player_ship.second) {
			if (potential_ship.owner_id != player_id) {
				double dist = ship.location.get_distance_to(potential_ship.location);
				if (dist < radius) {
					current_ship = potential_ship;
					radius = dist;
				}
			}
		}
	}

	return current_ship;
}

hlt::Ship FindABuddy(const hlt::Ship& ship, const hlt::Map& map, hlt::PlayerId player_id, double radius) {
	//Returns the ship if there are no near buddies, or the nearest buddy if there is one.
	hlt::Ship current_ship = ship;

	for (const hlt::Ship& s : map.ships.at(player_id)) {
		if (s.entity_id != ship.entity_id && s.docking_status == hlt::ShipDockingStatus::Undocked) {
			double dist = ship.location.get_distance_to(s.location);
			if (dist < radius) {
				current_ship = s;
				radius = dist;
			}
		}
	}

	return current_ship;
}

hlt::Planet FindClosestPlanet(const hlt::Ship& ship, std::vector<hlt::Planet> planets, hlt::PlayerId player_id) {
	//Returns the closest planet.
	hlt::Planet current_planet = planets[0];
	double shortest = 100000000;

	for (const hlt::Planet& planet : planets) {
		if ((!planet.is_full() && planet.owner_id == player_id) || planet.owner_id != player_id) {
			double dist = ship.location.get_distance_to(planet.location);
			if (dist < shortest) {
				current_planet = planet;
				shortest = dist;
			}
		}
	}

	return current_planet;
}